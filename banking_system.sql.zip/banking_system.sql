-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2020 at 02:31 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `contact_id` int(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`contact_id`, `fullname`, `email`, `message`) VALUES
(1, 'Dhoni', 'dhoni@gmail.com', 'transaction problem ');

-- --------------------------------------------------------

--
-- Table structure for table `senderaccount`
--

CREATE TABLE `senderaccount` (
  `s_no` int(255) NOT NULL,
  `sender_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `senderaccount`
--

INSERT INTO `senderaccount` (`s_no`, `sender_id`) VALUES
(1, 2),
(2, 2),
(3, 3),
(4, 6),
(5, 7),
(6, 4),
(7, 8),
(8, 9),
(9, 6),
(10, 3),
(11, 2),
(12, 4),
(13, 2),
(14, 2),
(15, 3),
(16, 3),
(17, 3),
(18, 3),
(19, 4),
(20, 4),
(21, 2),
(22, 4),
(23, 2),
(24, 2),
(25, 2),
(26, 3),
(27, 3),
(28, 2),
(29, 2),
(30, 10),
(31, 3),
(32, 2),
(33, 4),
(34, 2),
(35, 2),
(36, 10),
(37, 7),
(38, 1),
(39, 7),
(40, 6),
(41, 7),
(42, 7),
(43, 1),
(44, 7),
(45, 9),
(46, 1),
(47, 1),
(48, 5),
(49, 9),
(50, 8),
(51, 2),
(52, 4);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `sender_id` int(255) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `receiver_id` int(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `sender_id`, `sender_name`, `receiver_id`, `receiver_name`, `amount`, `remark`, `transaction_time`) VALUES
(1, 7, 'Rohit', 4, 'Gajini', '200', 'birthday wishes ', '2020-12-21 06:35:36'),
(2, 1, 'Mahendra', 7, 'Rohit', '1000', 'tourist places ', '2020-12-21 07:25:17'),
(3, 5, 'Sonali', 6, 'Deepak', '2000', 'rental', '2020-12-21 07:28:13'),
(4, 9, 'Vanshika', 1, 'Mahendra', '500', 'bus fare', '2020-12-21 07:37:16'),
(5, 2, 'Rajesh', 5, 'Sonali', '500', 'bus fare', '2020-12-21 11:42:06'),
(6, 4, 'Gajini', 1, 'Mahendra', '500', 'picnic ', '2020-12-21 12:41:06');

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--

CREATE TABLE `useraccounts` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `account_no.` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `ifsc_code` varchar(255) NOT NULL,
  `account_type` varchar(255) NOT NULL,
  `current_balance` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `useraccounts`
--

INSERT INTO `useraccounts` (`id`, `name`, `account_no.`, `branch_name`, `ifsc_code`, `account_type`, `current_balance`, `occupation`, `contact`, `address`, `date`) VALUES
(1, 'Mahendra', '45632245782	', 'SBP', 'SBIN0002356', 'Basic', '4000', 'BPO', '6789890874', 'Bangalore ', '2020-12-21 17:11:06'),
(2, 'Rajesh', '35634524978', 'SBP', 'SBIN0006794', 'Savings', '7000', 'Teacher', '7788390874', 'Chennai', '2020-12-21 16:12:06'),
(3, 'Janani', '98603624978', 'SBP', 'SBIN0001298', 'Savings', '7500', 'Engineer ', '7728990874', 'Chennai', '2020-12-12 12:17:55'),
(4, 'Gajini', '56603624219', 'SBP', 'SBIN0003578', 'Savings', '6000', 'Student ', '8898990874', 'Pune', '2020-12-21 17:11:06'),
(5, 'Sonali', '32638945795', 'SBP', 'SBIN0004581', 'Basic', '8500', 'House Maker ', '9089856874', 'Kochi', '2020-12-21 16:12:06'),
(6, 'Deepak', '56692145982', 'SBP', 'SBIN0005692', 'Basic', '7500', 'Army', '9780792874', 'Vellore', '2020-12-21 11:58:13'),
(7, 'Rohit', '35674124562', 'SBP', 'SBIN0001653', 'Savings', '3000', 'Lawyer', '7583908741', 'Mumbai ', '2020-12-21 11:55:17'),
(8, 'Dinesh', '67803625979', 'SBP', 'SBIN0009280', 'Savings', '8500', 'Police ', '9926590834', 'Bhopal ', '2020-12-12 12:36:32'),
(9, 'Vanshika', '68673624909', 'SBP', 'SBIN0007520', 'Savings', '2000', 'Doctor ', '9045930874', 'Mysore ', '2020-12-21 12:07:16'),
(10, 'Harshita', '89689745795', 'SBP', 'SBIN0004461', 'Basic', '9500', 'Farmer ', '8989456867', 'Salem', '2020-12-12 12:39:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `senderaccount`
--
ALTER TABLE `senderaccount`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `useraccounts`
--
ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `contact_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `senderaccount`
--
ALTER TABLE `senderaccount`
  MODIFY `s_no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `useraccounts`
--
ALTER TABLE `useraccounts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
